# Fududeeye Online — PostgreSQL Ready

This version uses PostgreSQL instead of SQLite.

## Render settings
- Build Command: `npm install`
- Start Command: `npm start`

## Required Environment Variables
- `DATABASE_URL` — PostgreSQL connection string
- `JWT_SECRET` — long random secret
- `ADMIN_USER` — admin username
- `ADMIN_PASSWORD` — admin password

`PORT` is optional; Render provides it automatically.

## Important
Do not commit real database passwords or secrets to GitHub.
Put them in Render Environment Variables.

The OTP sender is still DEMO and logs the OTP in the server logs. Connect a real SMS provider before production use.

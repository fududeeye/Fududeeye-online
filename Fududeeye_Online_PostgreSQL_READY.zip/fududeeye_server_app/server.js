const express = require('express');
const path = require('path');
const crypto = require('crypto');
const { Pool } = require('pg');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const app = express();
app.use(express.json({ limit: '1mb' }));

const PORT = process.env.PORT || 3000;
const DATABASE_URL = process.env.DATABASE_URL;
const JWT_SECRET = process.env.JWT_SECRET || 'CHANGE_ME_IN_PRODUCTION';
const ADMIN_USER = process.env.ADMIN_USER || 'admin';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'CHANGE_ME';

if (!DATABASE_URL) {
  console.error('DATABASE_URL is missing. Set it in Render Environment Variables.');
  process.exit(1);
}

const pool = new Pool({
  connectionString: DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production'
    ? { rejectUnauthorized: false }
    : false
});

async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS customers (
      id BIGSERIAL PRIMARY KEY,
      name TEXT NOT NULL,
      phone TEXT NOT NULL UNIQUE,
      dob TEXT NOT NULL,
      gender TEXT NOT NULL,
      city TEXT NOT NULL,
      password_hash TEXT NOT NULL,
      phone_verified BOOLEAN NOT NULL DEFAULT FALSE,
      created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS otp_verifications (
      id TEXT PRIMARY KEY,
      phone TEXT NOT NULL,
      purpose TEXT NOT NULL,
      payload JSONB,
      code_hash TEXT NOT NULL,
      expires_at BIGINT NOT NULL,
      attempts INTEGER NOT NULL DEFAULT 0,
      used BOOLEAN NOT NULL DEFAULT FALSE,
      created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
    );

    CREATE INDEX IF NOT EXISTS idx_otp_phone_purpose
      ON otp_verifications(phone, purpose);
  `);
  console.log('PostgreSQL tables are ready.');
}

function normalizePhone(v = '') {
  return String(v).replace(/\D/g, '').replace(/^252/, '').replace(/^0/, '');
}

function sign(user) {
  return jwt.sign(
    { id: user.id, phone: user.phone },
    JWT_SECRET,
    { expiresIn: '30d' }
  );
}

function auth(req, res, next) {
  const h = req.headers.authorization || '';
  if (!h.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Login required.' });
  }
  try {
    req.user = jwt.verify(h.slice(7), JWT_SECRET);
    next();
  } catch (e) {
    return res.status(401).json({ error: 'Session expired. Please login again.' });
  }
}

function makeOtp() {
  return String(Math.floor(100000 + Math.random() * 900000));
}

async function createOtp(phone, purpose, payload) {
  const id = crypto.randomUUID();
  const code = makeOtp();
  const codeHash = await bcrypt.hash(code, 10);
  const expires = Date.now() + 10 * 60 * 1000;

  await pool.query(
    `INSERT INTO otp_verifications
      (id, phone, purpose, payload, code_hash, expires_at)
     VALUES ($1, $2, $3, $4::jsonb, $5, $6)`,
    [id, phone, purpose, JSON.stringify(payload || {}), codeHash, expires]
  );

  return { id, code };
}

// Demo sender: logs OTP on the server.
// Replace this with a real SMS provider before production use.
async function sendSms(phone, code, purpose) {
  console.log(`[SMS DEMO] +252${phone} | ${purpose} | OTP: ${code}`);
  return { sent: true, demo: true };
}

app.post('/api/register/start', async (req, res) => {
  try {
    const { name, phone, dob, gender, city, password } = req.body || {};
    const p = normalizePhone(phone);

    if (!name || name.trim().length < 2) {
      return res.status(400).json({ error: 'Please enter your name.' });
    }
    if (p.length !== 9) {
      return res.status(400).json({ error: 'Please enter a valid +252 number.' });
    }
    if (!dob || !gender || !city || !password || password.length < 6) {
      return res.status(400).json({ error: 'Please complete all registration fields.' });
    }

    const existing = await pool.query(
      'SELECT id FROM customers WHERE phone = $1',
      [p]
    );
    if (existing.rowCount) {
      return res.status(409).json({ error: 'This phone number is already registered.' });
    }

    const passwordHash = await bcrypt.hash(password, 12);
    const payload = {
      name: name.trim(),
      phone: p,
      dob,
      gender,
      city,
      passwordHash
    };

    const o = await createOtp(p, 'register', payload);
    await sendSms(p, o.code, 'registration');

    res.json({ verificationId: o.id });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Server error.' });
  }
});

app.post('/api/register/resend', async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT * FROM otp_verifications
       WHERE id = $1 AND purpose = $2 AND used = FALSE`,
      [req.body?.verificationId, 'register']
    );
    const old = result.rows[0];

    if (!old) {
      return res.status(404).json({ error: 'Verification expired.' });
    }

    const payload = old.payload || {};
    const o = await createOtp(old.phone, 'register', payload);
    await sendSms(old.phone, o.code, 'registration');

    res.json({ verificationId: o.id });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Server error.' });
  }
});

app.post('/api/register/check', async (req, res) => {
  const client = await pool.connect();
  try {
    const { verificationId, code } = req.body || {};

    const result = await client.query(
      `SELECT * FROM otp_verifications
       WHERE id = $1 AND purpose = $2 AND used = FALSE`,
      [verificationId, 'register']
    );
    const o = result.rows[0];

    if (!o || Date.now() > Number(o.expires_at)) {
      return res.status(400).json({ error: 'Invalid or expired code.' });
    }
    if (o.attempts >= 5) {
      return res.status(429).json({ error: 'Too many attempts.' });
    }

    await client.query(
      'UPDATE otp_verifications SET attempts = attempts + 1 WHERE id = $1',
      [o.id]
    );

    if (!await bcrypt.compare(String(code || ''), o.code_hash)) {
      return res.status(400).json({ error: 'Incorrect verification code.' });
    }

    const p = o.payload || {};

    await client.query('BEGIN');
    const inserted = await client.query(
      `INSERT INTO customers
        (name, phone, dob, gender, city, password_hash, phone_verified)
       VALUES ($1, $2, $3, $4, $5, $6, TRUE)
       RETURNING id, name, phone, dob, gender, city, created_at`,
      [p.name, p.phone, p.dob, p.gender, p.city, p.passwordHash]
    );

    await client.query(
      'UPDATE otp_verifications SET used = TRUE WHERE id = $1',
      [o.id]
    );
    await client.query('COMMIT');

    const user = inserted.rows[0];
    res.json({ token: sign(user), user });
  } catch (e) {
    try { await client.query('ROLLBACK'); } catch (_) {}
    console.error(e);
    if (e.code === '23505') {
      return res.status(409).json({ error: 'This phone number is already registered.' });
    }
    res.status(500).json({ error: 'Server error.' });
  } finally {
    client.release();
  }
});

app.post('/api/login', async (req, res) => {
  try {
    const p = normalizePhone(req.body?.phone);
    const password = String(req.body?.password || '');

    const result = await pool.query(
      'SELECT * FROM customers WHERE phone = $1',
      [p]
    );
    const u = result.rows[0];

    if (!u || !await bcrypt.compare(password, u.password_hash)) {
      return res.status(401).json({ error: 'Phone number or password is incorrect.' });
    }

    res.json({
      token: sign(u),
      user: {
        id: u.id,
        name: u.name,
        phone: u.phone,
        dob: u.dob,
        gender: u.gender,
        city: u.city
      }
    });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Server error.' });
  }
});

app.get('/api/me', auth, async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT id, name, phone, dob, gender, city, created_at
       FROM customers WHERE id = $1`,
      [req.user.id]
    );
    const u = result.rows[0];

    if (!u) {
      return res.status(404).json({ error: 'Customer not found.' });
    }

    res.json({ user: u });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Server error.' });
  }
});

app.post('/api/forgot/start', async (req, res) => {
  try {
    const p = normalizePhone(req.body?.phone);

    const result = await pool.query(
      'SELECT id, phone FROM customers WHERE phone = $1',
      [p]
    );
    const u = result.rows[0];

    if (!u) {
      return res.status(404).json({ error: 'No account found for this phone number.' });
    }

    const o = await createOtp(p, 'forgot', { customerId: u.id });
    await sendSms(p, o.code, 'password reset');

    res.json({ verificationId: o.id });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Server error.' });
  }
});

app.post('/api/forgot/check', async (req, res) => {
  try {
    const { verificationId, code, newPassword } = req.body || {};

    if (!newPassword || newPassword.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters.' });
    }

    const result = await pool.query(
      `SELECT * FROM otp_verifications
       WHERE id = $1 AND purpose = $2 AND used = FALSE`,
      [verificationId, 'forgot']
    );
    const o = result.rows[0];

    if (!o || Date.now() > Number(o.expires_at)) {
      return res.status(400).json({ error: 'Invalid or expired code.' });
    }
    if (o.attempts >= 5) {
      return res.status(429).json({ error: 'Too many attempts.' });
    }

    await pool.query(
      'UPDATE otp_verifications SET attempts = attempts + 1 WHERE id = $1',
      [o.id]
    );

    if (!await bcrypt.compare(String(code || ''), o.code_hash)) {
      return res.status(400).json({ error: 'Incorrect verification code.' });
    }

    const p = o.payload || {};
    const hash = await bcrypt.hash(newPassword, 12);

    await pool.query(
      `UPDATE customers
       SET password_hash = $1, updated_at = CURRENT_TIMESTAMP
       WHERE id = $2`,
      [hash, p.customerId]
    );

    await pool.query(
      'UPDATE otp_verifications SET used = TRUE WHERE id = $1',
      [o.id]
    );

    res.json({ ok: true });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Server error.' });
  }
});

// Simple admin API protected with HTTP Basic Auth.
function admin(req, res, next) {
  const h = req.headers.authorization || '';
  if (!h.startsWith('Basic ')) {
    return res
      .status(401)
      .set('WWW-Authenticate', 'Basic realm="Fududeeye Admin"')
      .json({ error: 'Admin login required.' });
  }

  try {
    const decoded = Buffer.from(h.slice(6), 'base64').toString();
    const separator = decoded.indexOf(':');
    const u = separator >= 0 ? decoded.slice(0, separator) : '';
    const p = separator >= 0 ? decoded.slice(separator + 1) : '';

    if (u !== ADMIN_USER || p !== ADMIN_PASSWORD) throw new Error('Invalid admin');
    next();
  } catch (e) {
    return res
      .status(401)
      .set('WWW-Authenticate', 'Basic realm="Fududeeye Admin"')
      .json({ error: 'Invalid admin credentials.' });
  }
}

app.get('/api/admin/customers', admin, async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT id, name, phone, dob, gender, city,
              phone_verified, created_at, updated_at
       FROM customers ORDER BY id DESC`
    );
    res.json({ customers: result.rows });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Server error.' });
  }
});

app.get('/api/admin/stats', admin, async (req, res) => {
  try {
    const total = await pool.query('SELECT COUNT(*)::int AS c FROM customers');
    const verified = await pool.query(
      'SELECT COUNT(*)::int AS c FROM customers WHERE phone_verified = TRUE'
    );
    res.json({
      total: total.rows[0].c,
      verified: verified.rows[0].c
    });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Server error.' });
  }
});

app.get('/admin', admin, (req, res) => {
  res.sendFile(path.join(__dirname, 'admin.html'));
});

app.use(express.static(__dirname));

initDb()
  .then(() => {
    app.listen(PORT, () => {
      console.log(`Fududeeye server running on port ${PORT}`);
    });
  })
  .catch((err) => {
    console.error('Database initialization failed:', err);
    process.exit(1);
  });

process.on('SIGTERM', async () => {
  await pool.end();
  process.exit(0);
});
